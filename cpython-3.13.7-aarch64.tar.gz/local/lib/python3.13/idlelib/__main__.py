"""
IDLE main entry point

Run IDLE as python -m idlelib
"""
import idlelib.pyshell
idlelib.pyshell.main()
